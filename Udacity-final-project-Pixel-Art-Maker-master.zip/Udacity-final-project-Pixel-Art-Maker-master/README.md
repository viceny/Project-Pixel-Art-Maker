# Udacity-final-project---Pixel-Art-Maker
My final project from the Udacity Scholarship course on Front-end Developer.
The Project is to test my Ablities on the course i have learnt so far on Html, Css, and Javascript.
The Pixel Art Maker is developed to have the following function:
To create a grid of squares representing their design, and apply colors to those squares to create a digital masterpiece.

The project is created using Html, Css and Javascript.
check out the project here:

https://igwonobe.github.io/Udacity-final-project-Pixel-Art-Maker/
